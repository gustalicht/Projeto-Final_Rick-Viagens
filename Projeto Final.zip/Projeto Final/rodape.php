<footer id="rodape">
			<div class="social-media">
				<div class="icon">
					<a href="#"> <i class="fa-brands fa-instagram"></i>	</a>			
				</div>
			</div>	

			<div class="social-media">
				<div class="icon">
					<a href="#"> <i class="fa-brands fa-whatsapp"></i>	</a>			
				</div>
			</div>	

			<div class="social-media">
				<div class="icon">
					<a href="#"> <i class="fa-brands fa-facebook"></i>	</a>			
				</div>
			</div>	
			<div>
				<h5>Todos os direitos reservados.</h5>
			</div>
		</footer>

		<div class="whats">
			<p class="wha">
				<a href="#"> 
					<i class="fa-brands fa-whatsapp"></i>
					Fale Conosco!
				</a>
			</p>
		</div>