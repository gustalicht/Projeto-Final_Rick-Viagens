<?php

require_once "functions.php";
deslogar();
//redirecionamento de página
header("location: login.php");