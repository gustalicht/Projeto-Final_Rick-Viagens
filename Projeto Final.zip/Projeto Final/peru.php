<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Rick Viagens & intercambios</title>
		<link rel="stylesheet" type="text/css" href="peru.css">
		<link rel="icon" type="image/icon-x" href="image/aviao.png">
		<link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Kaushan+Script&family=Open+Sans:wght@400;800&display=swap" rel="stylesheet">
	</head>
	<body>
			
	<?php require_once "menu.php"; ?>

		<section class="container">

			
			<div class="banner">
				<h2>Peru</h2>
			</div>

			<div class="titulo">
					<h3>Principais Destinos</h3>
			</div>

			<div id="galeria">		
				<div class="conteudo">
					<div>
						<img src="image/machu.jpg" alt="Machu Picchu">
					</div>
					<h4>Machu Picchu</h4>
					<p>Começando pelo ponto alto, literalmente, da sua viagem, vale muito a pena encarar a fila para subir no segundo e no último degrau da Torre Eiffel, que tem mais de 300 metros de altura no total. Além de visitar um dos pontos turísticos mais famosos do mundo, você ainda terá uma visão panorâmica de tirar o fôlego. Uma viagem a Paris só estará completa com uma ida ao Museu do Louvre, que tem um dos acervos mais importantes do mundo. O lugar conta com mais de 30 mil obras e, por isso, facilmente você gastará um dia inteiro entre os vários corredores do Louvre. Entre suas obras mais importantes estão a Mona Lisa, de Leonardo da Vinci, e a escultura da Vênus de Milo. Também merece destaque a ala dedicada à cultura egípcia.</p>
				</div>

				<div class="conteudo">
					<div>
						<img src="image/lima.jpg" alt="Lima">	
					</div>		
					<h4>Lima</h4>
					<p>Nice, a capital da Riviera Francesa, é um destino dos sonhos. A cidade é uma das mais visitadas da França e não é para menos: Nice é alegre, tem um ar de glamour, é banhada pelas águas azuis do Mar Mediterrâneo e tem sol quase o ano inteiro. Caminhar por Nice é uma delícia. Além de ser uma ótima forma de conhecer a cidade, ainda permite observar de perto a natureza exuberante e todo charme de suas ruas. Nice é a quinta cidade mais populosa da França, com aproximadamente 350 mil habitantes. A cidade é a capital da Riviera Francesa e está localizada no sul do país e a apenas 30 km da fronteira com a Itália. É vizinha de Cannes – a 32 km de distância – e está bem próxima de Mônaco – a 21 km.</p>
				</div>

				<div class="conteudo">
					<div>
						<img src="image/cusco.jpg" alt="Cusco">
					</div>
					<h4>Cusco</h4>
					<p>Tours pode ser considerada uma cidade central da França para você fazer seu roteiro pelo Vale do Loire e aqui eu vou te contar quais os principais destinos para conhecer em seu entorno. Além de como aproveitar ao máximo a própria cidade, onde comer e se hospedar. Seja sua primeira vez em Tours ou se já visitou a cidade do Vale do Loire, saiba que há passeios para 1 ou 2 dias na cidade e região. Há tantas coisas legais para fazer em Tours, que mesmo visitando a cidade inúmeras vezes seria quase impossível conhecer tudo. Mas não se preocupe, pois a RICK trz para você uma lista com sugestões de lugares onde ir pela primeira vez na cidade, te ajudando a organizar tudo o que fazer em Tours.</p>
				</div>
			</div>





		</section>

		<?php require_once "rodape.php"; ?>

	</body>
</html>