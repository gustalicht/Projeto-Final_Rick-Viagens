<div id="galeria">
					<div class="col">
						<div class="card">
							<a href="frança.php">
								<img src="image/franca.jpg" alt="França">
								<h4>França</h4>
							</a>
						</div>
					</div>
				
					<div class="col">
						<div class="card">
							<a href="inglaterra.php">
								<img src="image/inglaterra.jpg" alt="Ingalteraa">		
								<h4>Inglaterra</h4>
							</a>
						</div>
					</div>
				
					<div class="col">
						<div class="card">
							<a href="argentina.php">
								<img src="image/argentina.jpg" alt="Argentina">
								<h4>Argentina</h4>
							</a>
						</div>
					</div>
				
					<div class="col">
						<div class="card">
							<a href="peru.php">
								<img src="image/peru.jpg" alt="Peru">
								<h4>Peru</h4>
							</a>
						</div>
					</div>
				</div>

				<div id="galeria2">
					<div class="col">
						<div class="card">
							<img src="image/eua.jpg" alt="EUA">
							<h4>EUA</h4>
						</div>
					</div>

					<div class="col">
						<div class="card">
							<img src="image/canada.jpg" alt="Canada">		
							<h4>Canada</h4>
						</div>
					</div>

					<div class="col">
						<div class="card">
							<img src="image/australia.jpg" alt="Australia">
							<h4>Australia</h4>
						</div>
					</div>

					<div class="col">
						<div class="card">
							<img src="image/africa.jpg" alt="Africa">
							<h4>Africa</h4>
						</div>
					</div>
				</div>
			</div>
		</section>