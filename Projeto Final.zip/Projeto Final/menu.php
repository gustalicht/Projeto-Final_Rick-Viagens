<header>	
			<nav id="topo" class="container"> 
				<div>
					<div id= "logo">
		<!-- na tag <a> vai algum link que direcione para o quem somos ou para a própria página inicial -->
						<a href="trabalhe_conosco.php"> <img src="image/logo-03.png" alt="logo Rick"> </a>
					</div>
					<div id="menu">
						<ul>
							
							<!-- colocar na tag <a> os links das outras páginas-->
                            <li class="menu-item"> 
								<a href="index.php">Home</a> 
							</li>
							<li class="menu-item"> 
								<a href="login.php">Página Administrativa(em construção)</a> 
							</li>
							<li class="menu-item submenu"> 
								<a href="html_pagina_hotelaria.php">Hotelaria</a> 								
							</li>
							
							<li class="menu-item"> 
								<a href="destinos.php">Destinos</a> 
							</li>
							
							<li class="menu-item submenu"> 
								<a href="trabalhe_conosco.php">Rick Viagens</a> 								
							</li>
						</ul>
					</div>
					
				</div>
			</nav>
			
		</header>